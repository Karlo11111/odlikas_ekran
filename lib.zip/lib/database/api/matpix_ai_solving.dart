import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;

class MathpixAiSolving {
  Future<String?> sendImageToMathpix(Uint8List imageBytes) async {
    // Encode image to base64
    String base64Image = base64Encode(imageBytes);

    // Mathpix API endpoint
    String apiUrl = 'https://api.mathpix.com/v3/text';

    // Your Mathpix credentials
    String appId = 'odlikas_6ea29e_d9d730';
    String appKey =
        '228114e8210928d372b6dae0eea561ae04c139d557395a7db8e2c21f96de3d5b';

    // Request headers
    Map<String, String> headers = {
      'app_id': appId,
      'app_key': appKey,
      'Content-Type': 'application/json',
    };

    // Request body
    Map<String, dynamic> body = {
      'src': 'data:image/png;base64,$base64Image',
      'formats': ['text', 'data'],
      'data_options': {
        'include_latex': true,
      },
    };

    // Send POST request
    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: headers,
        body: jsonEncode(body),
      );

      if (response.statusCode == 200) {
        // Parse the response
        final responseData = jsonDecode(response.body);
        String latex = responseData['text'];
        print('LaTeX: $latex');

        return latex;
        // Handle the LaTeX string as needed
      } else {
        print('Error: ${response.statusCode}');
        print('Response: ${response.body}');
        return null;
      }
    } catch (e) {
      print('Error: $e');
      return null;
    }
  }
}
