import 'dart:async';
import 'dart:ui';

class Debouncer {
  final Duration delay;
  Timer? _timer;

  Debouncer({required this.delay});

  void run(VoidCallback action) {
    _timer?.cancel(); // prekini bilo koji prijasnji timer
    _timer = Timer(delay, action);
  }

  // nova cancel funkcij
  void cancel() {
    _timer?.cancel();
    _timer = null;
  }
}
